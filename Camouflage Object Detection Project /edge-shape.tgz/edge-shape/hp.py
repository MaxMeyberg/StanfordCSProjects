import torch.fft
import torch
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import os

# CAMO Dataset"
#folder_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/images/train'
folder_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/images/val'
#gen_edge_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/gen_e/images/train'
gen_edge_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/gen_e/images/val'

i =0

for filename in os.listdir(folder_path):
    img_path = os.path.join(folder_path, filename)
    gen_file = os.path.join(gen_edge_path, filename)
    # YOLO can use jpg, png etc..
    gen0_file_path = os.path.splitext(gen_file)[0]+'_1.png'
    gen1_file_path = os.path.splitext(gen_file)[0]+'_2.png'
    img = Image.open(img_path)
    img = img.convert('L') # Gray scale
    img = np.array(img)
    img = torch.from_numpy(img)
    print(img.shape, gen0_file_path)

    fft_img = torch.fft.fft2(img)
    print(fft_img.shape)
    print(fft_img[0][:5])
    i += 1
    # Now Highpass filter

    hp_image = np.fft.fftshift(fft_img)
    #hp_image = highpass(fft_img)
    filter_rate=0.1
    h, w = hp_image.shape[:2]
    # center
    cy, cx = h//2, w//2
    filter_h = int(filter_rate * cy)
    filter_w = int(filter_rate * cx)

    hp_image[cy - filter_h:cy+filter_h, cx - filter_w:cx + filter_w] = 0

    # restore
    inverse_hp_image = np.fft.ifftshift(hp_image)
    #inverse_hp_image = inverse_highpass(hp_image)
    # inverse fft using torch
    ihp_img = torch.fft.ifft2(torch.from_numpy(inverse_hp_image))

    ihp_img = ihp_img.to('cpu').detach().numpy().copy()
    ihp_img = np.abs(9*ihp_img).clip(0,255).astype(np.uint8)
    #ihp_img = ihp_img.real.astype(np.uint8)
    plt.imshow(ihp_img, cmap="gray")
    plt.imsave(gen0_file_path, ihp_img)

print("Processed ", i, " files.")
