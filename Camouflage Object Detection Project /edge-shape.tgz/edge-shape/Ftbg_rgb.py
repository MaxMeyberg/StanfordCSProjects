# Usage
# python fft_bg_2D.py 'image.fits' 'im.st.fits' 'im.bg.fits' 0.9  1.0
# see below for the meanings of the arguments
# https://ui.adsabs.harvard.edu/abs/2015MNRAS.450.4043W/abstract
# Vinay Awasthi : I converted it from FITS to GreyScale (jpg/png).

from scipy import fftpack
import numpy as np
import astropy.io.fits as pyfits

import torch.fft
import torch
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np

import os

#folder_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/images/train' 
folder_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/images/val' 
#gen_shape_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/gen_s/images/train'
gen_shape_path = r'/data/900G/CAMO/CAMO-COCO-V.1.0-CVIU2019/gen_s/images/val'

i = 0
for filename in os.listdir(folder_path):
    img_path = os.path.join(folder_path, filename)
    gen_file = os.path.join(gen_shape_path, filename)
    genfg_file_path = os.path.splitext(gen_file)[0]+'_fg.png'
    genbg_file_path = os.path.splitext(gen_file)[0]+'_bg.png'

    img = Image.open(img_path)
    img = img.convert('L')
    img = np.array(img)
    #img = torch.from_numpy(img)
    print(img.shape)
    FRAC = 0.8   # hi/lo freq fraction.

    fft_img = fftpack.fft2(img)
    print(fft_img.shape)
    print(fft_img[0][:5])
    i += 1
    hp_img = np.fft.fftshift(fft_img)

    # 2D Power spectrum
    sq_ = np.abs(hp_img)**2
    log_sq_ = np.log10(sq_)
    mask_sq_ = np.abs(fft_img)**2
    log_mask_sq_ = np.log10(mask_sq_)

    # separate out hi and lo frequencies
    m_lo = log_mask_sq_ <= np.max(log_mask_sq_)*FRAC
    m_hi = log_mask_sq_ > np.max(log_mask_sq_)*FRAC

    hi = fftpack.ifft2(fft_img*m_lo).real  # hi freq.
    lo = fftpack.ifft2(fft_img*m_hi).real  # lo freq.

    # background processing
    bg = lo.copy()
    bg *= np.median(img)/np.max(lo)
    fg = img - bg
    fg_img = fg.copy()
    fg_img = np.abs(3*fg_img).clip(0,255).astype(np.uint8) # 3 multiplication is to increase brightness.
    plt.imshow(fg_img, cmap='gray')
    plt.imsave(genfg_file_path, fg_img)

    bg_img = bg.copy()
    bg_img = np.abs(3*bg_img).clip(0,255).astype(np.uint8)
    plt.imshow(bg_img, cmap='gray')
    plt.imsave(genbg_file_path, bg_img)

print("Processed ", i, " files, generated fg, bg images.")
